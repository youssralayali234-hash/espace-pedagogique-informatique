Version V64 — définitions et exemples précis dans le style visuel

Modifications appliquées :
1. Dans les deux unités, les images du style visuel restent cliquables.
2. Le bouton affiché sur l’image devient : « Voir définition + exemple ».
3. Après un clic sur une image, l’application affiche maintenant :
   - la notion exacte montrée dans l’image ;
   - la définition claire de cette notion ;
   - un exemple précis à réaliser par l’élève ;
   - l’idée « Je retiens » ;
   - une consigne élève simple.
4. La modification est appliquée à l’unité Tableur et à l’unité Programmation LOGO.
5. Les exemples sont formulés comme des tâches concrètes : créer un classeur, saisir des données, écrire une formule, utiliser REPETE, créer une procédure LOGO, etc.

Utilisation : ouvrir index.html dans un navigateur.

V66 - Correction du style visuel :
- Réanalyse image par image pour les deux unités.
- Ajout d'une définition claire en haut de chaque image.
- Remplacement des exemples génériques par des exemples liés exactement à l'image affichée.
- Suppression des répétitions dans la partie « Voir l'exemple précis ».
- Exemples corrigés : bouton + pour ajouter une feuille, D2 = SOMME(A2,B2,C2), poignée de recopie, commandes LOGO AV/RE/TD/TG/BC/LC/VE/REPETE/POUR/ECRIS.


V114 — Modifications finales appliquées :
- Bordure bleue pour Système informatique.
- Bordure orange pour Système d’exploitation.
- Bordure verte pour Tableur.
- Bordure rouge pour Programmation LOGO.
- Arrière-plan général en dégradé mauve/blanc.
- Image d’accueil utilisée uniquement comme arrière-plan.
- Libellé À retenir en rouge uniquement dans les exemples d’images.
- Formulaire d’authentification recentré, moins large et plus professionnel.
- Authentification limitée aux élèves inscrits ; message d’erreur : Authentification incorrecte.
- Accès enseignant masqué dans l’application élève.


V115 : suppression de la version affichée en bas et du bloc associé sur la page d'accueil.


V117 : ajout de l’espace professeur uniquement dans la page d’authentification, suppression du bouton enseignant dans l’application élève et suppression de l’icône Édu Libre.


V118 : formulaire d’authentification recentré et simplifié, style plus professionnel, ajout d’un bloc À propos tout en bas de l’application.


V119 : nom de l’application remplacé par Espace pédagogique informatique, formulaire d’authentification légèrement élargi et centré, bloc À propos déplacé dans la page d’authentification.


V122 — Nouvelle version générée : EPI_Informatique_v122_formulaire_centre_gauche
- Formulaire placé centre-gauche, centré verticalement.
- Arrière-plan centré et formulaire allégé conservé.


V123 - Ajustement demandé :
- Version gauche uniquement modifiée.
- Formulaire élargi légèrement.
- Formulaire déplacé davantage vers la gauche.
- Contenu principal de l’application conservé.
