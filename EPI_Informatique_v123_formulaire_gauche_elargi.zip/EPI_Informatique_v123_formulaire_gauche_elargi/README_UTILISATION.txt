Utilisation de l’application Edu Libre V64

1. Décompressez le dossier.
2. Ouvrez le fichier index.html dans Google Chrome ou Microsoft Edge.
3. Choisissez le profil élève ou professeur selon l’usage prévu.
4. Entrez dans une unité, puis ouvrez une leçon.
5. Dans le style visuel, cliquez sur « Voir définition + exemple » sur chaque image.
6. L’application affiche la définition de la notion et un exemple précis à réaliser.

Remarque : les boutons audio utilisent la synthèse vocale du navigateur. Pour une meilleure voix arabe, utilisez Chrome ou Edge avec une voix arabe installée.
